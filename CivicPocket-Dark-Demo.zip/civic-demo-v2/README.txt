CIVIC POCKET DEMO — CLOUDFLARE PAGES

1. Unzip the downloaded ZIP in the iPhone Files app.
2. In Cloudflare Dashboard > Workers & Pages, create a Pages project using Direct Upload.
3. Upload the extracted civic-demo-v2 folder, with index.html at its root.
4. Deploy and open the generated pages.dev URL in Safari.
5. Safari Share > Add to Home Screen.

This is an independent interface prototype, not Service NSW. The card is deliberately sample-only and cannot be used as identification.
